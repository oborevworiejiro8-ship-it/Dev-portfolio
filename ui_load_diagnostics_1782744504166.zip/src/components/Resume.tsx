import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

const experiences = [
  {
    title: "Senior Full Stack Developer",
    company: "Tech Innovators Inc.",
    period: "2021 - Present",
    description: "Lead developer for multiple high-traffic web applications, managing a team of 5 engineers and implementing scalable architectures.",
  },
  {
    title: "Web Developer",
    company: "Creative Solutions Agency",
    period: "2018 - 2021",
    description: "Designed and developed custom websites for international clients, focusing on responsive design and performance optimization.",
  },
  {
    title: "Junior Developer",
    company: "StartUp Hub",
    period: "2016 - 2018",
    description: "Assisted in the development of core product features and maintained legacy codebases while learning modern web technologies.",
  },
];

const skills = [
  "React", "TypeScript", "Node.js", "Tailwind CSS", "PostgreSQL",
  "GraphQL", "Next.js", "AWS", "Docker", "UI/UX Design"
];

export function Resume() {
  return (
    <section id="resume" className="py-20 bg-muted/30">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Resume</h2>
            <p className="text-muted-foreground mt-2">A summary of my professional journey and skills.</p>
          </div>
          <Button className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download PDF
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-8">
            <h3 className="text-xl font-semibold mb-6">Experience</h3>
            <div className="relative border-l border-border ml-3 pl-8 space-y-12">
              {experiences.map((exp, index) => (
                <div key={index} className="relative">
                  <div className="absolute -left-[41px] top-1 w-4 h-4 rounded-full bg-primary border-4 border-background" />
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline gap-2 mb-2">
                    <h4 className="text-lg font-bold">{exp.title}</h4>
                    <span className="text-sm font-medium text-muted-foreground bg-muted px-2 py-1 rounded">{exp.period}</span>
                  </div>
                  <p className="text-primary font-medium mb-3">{exp.company}</p>
                  <p className="text-muted-foreground leading-relaxed">{exp.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-6">Skills & Expertise</h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="px-3 py-1 text-sm">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <Card className="bg-primary text-primary-foreground">
              <CardContent className="pt-6">
                <h4 className="text-lg font-bold mb-2">Education</h4>
                <p className="font-medium">B.Sc. in Computer Science</p>
                <p className="text-primary-foreground/80 text-sm">University of Technology, 2012 - 2016</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

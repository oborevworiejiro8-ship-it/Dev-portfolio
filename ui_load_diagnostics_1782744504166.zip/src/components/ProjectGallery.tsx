import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { ExternalLink, Github } from "lucide-react";

const projects = [
  {
    id: 1,
    title: "E-commerce Platform",
    category: "Web Development",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/e-commerce-platform-ece3be7b-1781795810987.webp",
    description: "A full-featured e-commerce solution with real-time inventory management and secure payment integration.",
    longDescription: "This project involved building a robust e-commerce engine from scratch. Key features include a custom shopping cart, integration with Stripe for payments, and a dynamic admin dashboard for product management. The frontend was built with React and Tailwind CSS for a seamless user experience.",
    tech: ["React", "Node.js", "Stripe", "Tailwind"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/e-commerce-platform-ece3be7b-1781795810987.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/finance-dashboard-e481d0a3-1781795809964.webp"
    ]
  },
  {
    id: 2,
    title: "Social Media App",
    category: "Mobile App",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/social-media-app-a1f0490b-1781795810550.webp",
    description: "A modern social platform focused on visual content sharing and community engagement.",
    longDescription: "Designed to handle high volumes of image uploads and real-time interactions. The app features a personalized feed, direct messaging, and advanced privacy controls. Built with a focus on performance and mobile responsiveness.",
    tech: ["React Native", "Firebase", "TypeScript"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/social-media-app-a1f0490b-1781795810550.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/design-portfolio-068861de-1781795810537.webp"
    ]
  },
  {
    id: 3,
    title: "AI Chatbot",
    category: "AI / Machine Learning",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/ai-chatbot-2a4d80a1-1781795810670.webp",
    description: "An intelligent customer support bot capable of handling complex queries using NLP.",
    longDescription: "Leveraging state-of-the-art NLP models, this chatbot provides human-like responses and can be integrated into various platforms. It includes a learning mechanism to improve over time based on user feedback.",
    tech: ["Python", "OpenAI", "React", "WebSocket"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/ai-chatbot-2a4d80a1-1781795810670.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/fitness-app-27945b5c-1781795810800.webp"
    ]
  },
  {
    id: 4,
    title: "Design Portfolio",
    category: "UI/UX Design",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/design-portfolio-068861de-1781795810537.webp",
    description: "A minimalist portfolio for showcasing creative works with a focus on typography.",
    longDescription: "A highly customized portfolio site that emphasizes visual storytelling. It features smooth transitions, a clean grid layout, and an interactive gallery for high-resolution images.",
    tech: ["Framer Motion", "React", "Tailwind"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/design-portfolio-068861de-1781795810537.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/e-commerce-platform-ece3be7b-1781795810987.webp"
    ]
  },
  {
    id: 5,
    title: "Finance Dashboard",
    category: "Web Application",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/finance-dashboard-e481d0a3-1781795809964.webp",
    description: "Complex data visualization tool for personal and corporate finance tracking.",
    longDescription: "A comprehensive dashboard for monitoring financial health. It includes real-time stock tracking, expense categorization, and predictive analytics for budgeting. Built with D3.js for advanced charting.",
    tech: ["D3.js", "React", "Chart.js", "PostgreSQL"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/finance-dashboard-e481d0a3-1781795809964.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/social-media-app-a1f0490b-1781795810550.webp"
    ]
  },
  {
    id: 6,
    title: "Fitness App",
    category: "Mobile App",
    image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/fitness-app-27945b5c-1781795810800.webp",
    description: "A health-focused mobile application for tracking workouts and nutrition goals.",
    longDescription: "This app helps users stay on track with their fitness journey by providing personalized workout plans, meal tracking, and community challenges. Features integration with wearable devices for real-time data syncing.",
    tech: ["React Native", "Redux", "HealthKit"],
    images: [
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/fitness-app-27945b5c-1781795810800.webp",
      "https://storage.googleapis.com/dala-prod-public-storage/generated-images/bb6b953a-9325-4d2d-b664-368ed07eda48/ai-chatbot-2a4d80a1-1781795810670.webp"
    ]
  }
];

export function ProjectGallery() {
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  return (
    <section id="projects" className="py-20 bg-background">
      <div className="container px-4 mx-auto">
        <div className="mb-12">
          <h2 className="text-3xl font-bold tracking-tight">Project Gallery</h2>
          <p className="text-muted-foreground mt-2">A showcase of my recent work and creative experiments.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <Card
              key={project.id}
              className="group overflow-hidden cursor-pointer border-none shadow-md hover:shadow-xl transition-all duration-300"
              onClick={() => setSelectedProject(project)}
            >
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <span className="text-white font-medium border border-white px-4 py-2 rounded-full">View Project</span>
                </div>
              </div>
              <CardContent className="p-6">
                <span className="text-xs font-semibold uppercase tracking-wider text-primary">{project.category}</span>
                <h3 className="text-xl font-bold mt-2">{project.title}</h3>
                <p className="text-muted-foreground mt-2 text-sm line-clamp-2">{project.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        {selectedProject && (
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">{selectedProject.title}</DialogTitle>
              <DialogDescription>{selectedProject.category}</DialogDescription>
            </DialogHeader>
            <div className="mt-4 space-y-6">
              <Carousel className="w-full">
                <CarouselContent>
                  {selectedProject.images.map((img, idx) => (
                    <CarouselItem key={idx}>
                      <div className="aspect-video relative overflow-hidden rounded-lg">
                        <img src={img} alt={`${selectedProject.title} ${idx + 1}`} className="object-cover w-full h-full" />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious className="left-2" />
                <CarouselNext className="right-2" />
              </Carousel>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-4">
                  <h4 className="text-lg font-semibold">About the Project</h4>
                  <p className="text-muted-foreground leading-relaxed">{selectedProject.longDescription}</p>
                </div>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold uppercase tracking-wider mb-3">Technologies</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.tech.map((t) => (
                        <span key={t} className="text-xs bg-muted px-2 py-1 rounded">{t}</span>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button className="w-full flex items-center justify-center gap-2">
                      <ExternalLink className="h-4 w-4" /> Live Demo
                    </Button>
                    <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                      <Github className="h-4 w-4" /> View Code
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </section>
  );
}

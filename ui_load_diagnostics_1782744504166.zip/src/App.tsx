import { ThemeProvider } from "./components/ThemeProvider";
import { Navbar } from "./components/Navbar";
import { ProjectGallery } from "./components/ProjectGallery";
import { Resume } from "./components/Resume";
import { ContactForm } from "./components/ContactForm";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { ArrowRight, Github, Linkedin, Twitter } from "lucide-react";

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="portfolio-theme">
      <div className="min-h-screen bg-background text-foreground font-sans">
        <Navbar />
        
        <main>
          {/* Hero Section */}
          <section className="pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
            <div className="container px-4 mx-auto">
              <div className="max-w-3xl">
                <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
                  Building digital <span className="text-primary">experiences</span> that matter.
                </h1>
                <p className="text-xl text-muted-foreground mb-10 leading-relaxed max-w-2xl">
                  I'm a full-stack developer specializing in building exceptional digital experiences. 
                  Currently, I'm focused on building accessible, human-centered products.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button size="lg" className="rounded-full px-8">
                    View Projects <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button size="lg" variant="outline" className="rounded-full px-8">
                    Contact Me
                  </Button>
                </div>
                <div className="flex items-center gap-6 mt-12 text-muted-foreground">
                  <a href="#" className="hover:text-primary transition-colors"><Github size={24} /></a>
                  <a href="#" className="hover:text-primary transition-colors"><Linkedin size={24} /></a>
                  <a href="#" className="hover:text-primary transition-colors"><Twitter size={24} /></a>
                </div>
              </div>
            </div>
          </section>

          <ProjectGallery />
          <Resume />
          <ContactForm />
        </main>

        <footer className="py-12 border-t border-border">
          <div className="container px-4 mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} DevPortfolio. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">Built with React, Tailwind & Love.</p>
          </div>
        </footer>
        
        <Toaster position="bottom-right" />
      </div>
    </ThemeProvider>
  );
}
export default App;

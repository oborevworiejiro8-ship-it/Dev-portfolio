# Portfolio Builder Frontend Implementation Plan

Build a responsive portfolio builder UI for freelancers, featuring a project gallery, contact form, resume section, and dark mode.

## Scope Summary
- **Project Gallery:** Responsive grid of project thumbnails with a lightbox/carousel detail view.
- **Contact Form:** Client-side validated form with feedback.
- **Resume Section:** Structured UI for timelines and skills, including a PDF download button.
- **Dark Mode:** Theme toggle with persistent state using CSS variables and Tailwind.
- **Data:** Mock data for initial UI (client-side only). No database/Supabase.

## Affected Areas
- `src/App.tsx`: Main layout and routing/scrolling orchestration.
- `src/components/`: New components for Gallery, ProjectDetail, Resume, ContactForm, and ThemeToggle.
- `src/index.css`: Verification of dark mode variables (already present in preflight).
- `src/hooks/`: Custom hook for theme management.

## Phases

### Phase 1: Foundation & Theme Management
- Implement `ThemeProvider` and `useTheme` hook to handle dark mode.
- Add a `ThemeToggle` component using `src/components/ui/switch.tsx`.
- Ensure `src/index.css` variables are correctly mapped to the theme.
- **Owner:** `frontend_engineer`

### Phase 2: Resume Section
- Create `Resume` component with experience timeline and skill proficiency bars.
- Use `src/components/ui/badge.tsx` for skills.
- Add a "Download PDF" button (mock action/UI only).
- **Owner:** `frontend_engineer`

### Phase 3: Project Gallery & Detail View
- Create `ProjectGallery` component with a responsive grid.
- Implement `ProjectCard` for thumbnails.
- Create `ProjectDetail` lightbox or modal using `src/components/ui/dialog.tsx` and `src/components/ui/carousel.tsx`.
- **Owner:** `frontend_engineer`

### Phase 4: Contact Form
- Implement `ContactForm` using `src/components/ui/form.tsx`, `input.tsx`, and `textarea.tsx`.
- Add client-side validation (e.g., using `react-hook-form` or simple state).
- Add success/error feedback messages using `src/components/ui/sonner.tsx`.
- **Owner:** `frontend_engineer`

### Phase 5: Layout & Final Polish
- Assemble all sections in `App.tsx`.
- Add smooth scrolling and navigation.
- Final responsive check.
- **Owner:** `frontend_engineer`

## Execution Handoff

**Plan status:** ready

**Dispatch order:**
1. frontend_engineer — Builds all UI components and interactivity.

**Per-agent instructions:**
### 1. frontend_engineer
- **Phases:** 1-5
- **Scope:** Complete frontend implementation of the portfolio builder. Use the existing UI components in `src/components/ui/`.
- **Files:** `src/App.tsx`, new files in `src/components/`, `src/hooks/use-theme.ts`.
- **Depends on:** none
- **Acceptance criteria:** 
    - Dark mode toggle works and persists.
    - Gallery displays projects; clicking one opens a carousel/lightbox.
    - Contact form validates inputs and shows feedback on "Submit".
    - Resume section is responsive and includes a download button.
    - Layout is mobile-friendly.

**Do not dispatch:**
- supabase_engineer (no database requested)
- quick_fix_engineer (frontend_engineer covers all initial build)
